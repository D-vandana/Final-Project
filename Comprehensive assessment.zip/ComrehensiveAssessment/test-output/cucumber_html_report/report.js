$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:Features/AboutUs.feature");
formatter.feature({
  "name": "Validating the About Us",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder About Us page",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "user Open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "MainClass.user_open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user click on About Us page",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.user_click_on_about_us_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "verify whether  Honesty \u0026 Transparency is appropriate or not",
  "keyword": "Then "
});
formatter.match({
  "location": "MainClass.verify_whether_honesty_transparency_is_appropriate_or_not()"
});
formatter.result({
  "error_message": "org.openqa.selenium.WebDriverException: chrome not reachable\n  (Session info: chrome\u003d101.0.4951.67)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027MINDC1D218\u0027, ip: \u0027172.16.84.162\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u002717.0.2\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 101.0.4951.67, chrome: {chromedriverVersion: 100.0.4896.60 (6a5d10861ce8..., userDataDir: C:\\Users\\MINDSD~1\\AppData\\L...}, goog:chromeOptions: {debuggerAddress: localhost:53050}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true}\nSession ID: 1788a9a7637eeb6c1ab0e182768af12a\n*** Element info: {Using\u003dxpath, value\u003d//ul[@class\u003d\u0027no-bullet\u0027]/li[3]}\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:77)\r\n\tat java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.base/java.lang.reflect.Constructor.newInstanceWithCaller(Constructor.java:499)\r\n\tat java.base/java.lang.reflect.Constructor.newInstance(Constructor.java:480)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:428)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat jdk.proxy2/jdk.proxy2.$Proxy19.getText(Unknown Source)\r\n\tat com.stepDefinitions.MainClass.verify_whether_honesty_transparency_is_appropriate_or_not(MainClass.java:160)\r\n\tat ✽.verify whether  Honesty \u0026 Transparency is appropriate or not(file:Features/AboutUs.feature:7)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "MainClass.close_the_website()"
});
formatter.result({
  "status": "skipped"
});
formatter.uri("file:Features/Fee\u0026Payment.feature");
formatter.feature({
  "name": "Validating the Fee\u0026Payment",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder Sales page",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "user Open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "MainClass.user_open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Fee \u0026 Payment",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.click_on_fee_payment()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "verify whether TERMS OF SHIPPING AND DELIVERY is featured or not",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.verify_whether_terms_of_shipping_and_delivery_is_featured_or_not()"
});
formatter.result({
  "error_message": "org.openqa.selenium.WebDriverException: chrome not reachable\n  (Session info: chrome\u003d101.0.4951.67)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027MINDC1D218\u0027, ip: \u0027172.16.84.162\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u002717.0.2\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 101.0.4951.67, chrome: {chromedriverVersion: 100.0.4896.60 (6a5d10861ce8..., userDataDir: C:\\Users\\MINDSD~1\\AppData\\L...}, goog:chromeOptions: {debuggerAddress: localhost:53102}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true}\nSession ID: 7aa5247932279e1444fc1e5a83f499c5\n*** Element info: {Using\u003dxpath, value\u003d//div[@id\u003d\u0027page_content\u0027]/p[5]/strong}\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:77)\r\n\tat java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.base/java.lang.reflect.Constructor.newInstanceWithCaller(Constructor.java:499)\r\n\tat java.base/java.lang.reflect.Constructor.newInstance(Constructor.java:480)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:428)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat jdk.proxy2/jdk.proxy2.$Proxy19.getText(Unknown Source)\r\n\tat com.stepDefinitions.MainClass.verify_whether_terms_of_shipping_and_delivery_is_featured_or_not(MainClass.java:129)\r\n\tat ✽.verify whether TERMS OF SHIPPING AND DELIVERY is featured or not(file:Features/Fee\u0026Payment.feature:7)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "MainClass.close_the_website()"
});
formatter.result({
  "status": "skipped"
});
formatter.uri("file:Features/GiftCard.feature");
formatter.feature({
  "name": "Validating the GiftCards",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder GiftCards footer page",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "user Open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "MainClass.user_open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user click on Gift Cards",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.user_click_on_gift_cards()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "verify whether First, choose an occasion is available or not",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.verify_whether_first_choose_an_occasion_is_available_or_not()"
});
formatter.result({
  "error_message": "org.openqa.selenium.WebDriverException: chrome not reachable\n  (Session info: chrome\u003d101.0.4951.67)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027MINDC1D218\u0027, ip: \u0027172.16.84.162\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u002717.0.2\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 101.0.4951.67, chrome: {chromedriverVersion: 100.0.4896.60 (6a5d10861ce8..., userDataDir: C:\\Users\\MINDSD~1\\AppData\\L...}, goog:chromeOptions: {debuggerAddress: localhost:53157}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:virtualAuthenticators: true}\nSession ID: fb13ceb3531532b933ba2a866a3b018c\n*** Element info: {Using\u003dxpath, value\u003d//section[@class\u003d\u0027_14QEd\u0027]/h2}\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:77)\r\n\tat java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.base/java.lang.reflect.Constructor.newInstanceWithCaller(Constructor.java:499)\r\n\tat java.base/java.lang.reflect.Constructor.newInstance(Constructor.java:480)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:428)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat jdk.proxy2/jdk.proxy2.$Proxy19.getText(Unknown Source)\r\n\tat com.stepDefinitions.MainClass.verify_whether_first_choose_an_occasion_is_available_or_not(MainClass.java:145)\r\n\tat ✽.verify whether First, choose an occasion is available or not(file:Features/GiftCard.feature:7)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "MainClass.close_the_website()"
});
formatter.result({
  "status": "skipped"
});
formatter.uri("file:Features/Login.feature");
formatter.feature({
  "name": "Entering  into UrbanLadder page",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder Login page",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "user Open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "MainClass.user_open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user click on Login page",
  "keyword": "And "
});
formatter.match({
  "location": "MainClass.user_click_on_login_page()"
});
